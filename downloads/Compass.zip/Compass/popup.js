
$(document).ready(function(){



	function logged_in(){

		$.post("http://localhost:8888/lr/extension-logged-in.php", function(data){
				if(data == 'logged-in'){
					$(".slide2").slideDown();
				}else{
					$(".slide1").slideDown();
					
				}
	           
	         });
	}

	logged_in();



	$("#login").on("click", function(){

		var email = $('input[name=email]').val();
		var pw = $('input[name=password]').val();



		var message = "email=" + email + "&password=" + pw;
		$.post("http://localhost:8888/lr/extension-login.php", message, function(data){
			if(data == "login"){
				$(".slide2").slideDown();
				$(".slide1").slideUp();
			}else if(data == "not-login"){
				alert("wrong username or password");
			}else{
				alert("something went wrong internally, we are working on it!");
			}
		})
		
	})



chrome.tabs.getSelected(null, function(tab) {
    $('#get_url').val(tab.url);
    $('#get_title').val(tab.title);
    $('.tab-url').html(tab.title);
});

// Get tags from database
// Get Categories

$( "#categories" ).load( "http://localhost:8888/lr/extension-categories.php" );
$( "#tags" ).load( "http://localhost:8888/lr/extension-tags.php" );   

// Add Tags to form-field


$("p.tag").on("click", function(){
	console.log('hmm');
	content = $(this).html(); 
	cur_val = $("input[name=tags]").val();

	if(cur_val){
		$("input[name=tags]").val(cur_val + " " + content);
	
	}else{
		$("input[name=tags]").val(content);
	}
	
})


$('#speichern').on("click", function(){

	var url = $("input[name=url]").val();
	var title = $("input[name=title]").val();
	var category = $("select[name=categories]").val();
	var tags = $("input[name=tags]").val();
	var description = $("textarea[name=description]").val();
	
	var message = "url=" + url + "&title=" + title + "&category=" + category + "&tags=" + tags + "&description=" + description;
	$.post("http://localhost:8888/lr/extension.php", message, function(data){
	            if(data == "awesome"){
	            	$(".slide2").slideUp();
					$(".slide3").slideDown();
	            }else{
	            	console.log('something went wrong...');
	            }
	         });

	
	
})





	



}) // End of document ready